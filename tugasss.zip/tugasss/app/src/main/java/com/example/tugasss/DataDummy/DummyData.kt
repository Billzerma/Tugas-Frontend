package com.example.tugasss.DataDummy


import com.example.tugasss.R
import com.example.tugasss.model.Boss
import com.example.tugasss.model.Map


object DummyData {
    val TheBoss = listOf(
        Boss(
            id = 1,
            name = "Morgot",
            title = "The Omen King",
            region = "Erdtree",
            photo = R.drawable.morgot
        ),
        Boss(
            id = 2,
            name = "Godrick the Grafted",
            title = "The Grafted",
            region = "Stromveil Castle",
            photo = R.drawable.godrick
        ),
        Boss(
            id = 3,
            name = "Renalla",
            title = "The Full Moon",
            region = "Academy Raya Lucaria",
            photo = R.drawable.renalla
        ),
        Boss(
            id = 4,
            name = "Radahn",
            title = "The Starscourge",
            region = "Caelid",
            photo = R.drawable.radahn
        ),
        Boss(
            id = 5,
            name = "Rykard",
            title = "The Blasphemy",
            region = "Mountain Gelmir",
            photo = R.drawable.rykard
        ),
        Boss(
            id = 6,
            name = "Mogh",
            title = "Lord of Blood",
            region = "Moghwyn Pallace",
            photo = R.drawable.mohg
        ),
        Boss(
            id = 7,
            name = "Malenia",
            title = "Blade of Miquella",
            region = "Elphael",
            photo = R.drawable.malenia
        ),
        Boss(
            id = 8,
            name = "Maliketh",
            title = "The Black Blade",
            region = "Crumbling Farum Azulla",
            photo = R.drawable.maliketh
        ),
        Boss(
            id = 9,
            name = "Hoarah Lux",
            title = "Warrior",
            region = "Erdtree",
            photo = R.drawable.hoara
        ),
        Boss(
            id = 10,
            name = "Dragon Lord Placidusax",
            title = "Ancient Dragon",
            region = "Crumbling Farum Azulla",
            photo = R.drawable.dragon
        )

    )

    val TheMaps= listOf(
        Map(
            id = 1,
            name = "Limgrave",
            desc = "The Omen King",
            photo = R.drawable.limgrave
        ),
        Map(
            id = 2,
            name = "Caelid",
            desc = "The Omen King",
            photo = R.drawable.caelid
        ),
        Map(
            id = 3,
            name = "Stromveil Castle",
            desc = "The Omen King",
            photo = R.drawable.veil
        ),
        Map(
            id = 4,
            name = "Acamdemy Raya Lucaria",
            desc = "The Omen King",
            photo = R.drawable.raya
        ),
        Map(
            id = 5,
            name = "Elphael",
            desc = "The Omen King",
            photo = R.drawable.elpahel
        ),
        Map(
            id = 6,
            name = "Lyndell City",
            desc = "The Omen King",
            photo = R.drawable.lyndell
        ),
        Map(
            id = 7,
            name = "Mount Gelmir",
            desc = "The Omen King",
            photo = R.drawable.gelmir
        ),
        Map(
            id = 8,
            name = "Weeping Peninsulla",
            desc = "The Omen King",
            photo = R.drawable.weeping
        ),
        Map(
            id = 9,
            name = "Ainsell River",
            desc = "The Omen King",
            photo = R.drawable.ainsel
        ),
        Map(
            id = 10,
            name = "Nokron City",
            desc = "The Omen King",
            photo = R.drawable.nokron
        ),

        )



}