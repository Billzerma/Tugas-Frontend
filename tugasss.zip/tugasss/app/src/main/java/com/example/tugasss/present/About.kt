package com.example.tugasss.present

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp



@Composable
fun About() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Nama: Nabil Zerma Maulana")
        Text(text = "Email: 211111030@gmail.com")
        Text(text = "Perguruan Tinggi: STIKI Malang")
        Text(text = "Jurusan: Informatika")
        // Tambahkan gambar profil di sini

    }
}
