package com.example.tugasss.model

data class Map(
    val id: Int,
    val name: String,
    val desc: String,
    val photo: Int,
)
