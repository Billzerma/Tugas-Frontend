package com.example.tugasss.model

class Weapon (
    val id: Int,
    val name: String,
    val descWeapon: String,
    val photo: Int,
)