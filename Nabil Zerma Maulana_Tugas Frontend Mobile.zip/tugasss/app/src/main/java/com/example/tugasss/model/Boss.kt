package com.example.tugasss.model

data class Boss(
    val id: Int,
    val name: String,
    val title: String,
    val region: String,
    val photo: Int,
)
